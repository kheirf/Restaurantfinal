require 'test_helper'

class SubscribesHelperTest < ActionView::TestCase
end
