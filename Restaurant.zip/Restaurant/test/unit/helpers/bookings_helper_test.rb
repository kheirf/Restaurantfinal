require 'test_helper'

class BookingsHelperTest < ActionView::TestCase
end
