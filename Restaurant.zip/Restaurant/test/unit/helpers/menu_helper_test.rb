require 'test_helper'

class MenuHelperTest < ActionView::TestCase
end
