class MenuController < ApplicationController
  def displayMenu
  end
end
