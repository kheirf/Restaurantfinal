class Subscribe < ActiveRecord::Base
  attr_accessible :contactNo, :customerName, :email, :password
end
