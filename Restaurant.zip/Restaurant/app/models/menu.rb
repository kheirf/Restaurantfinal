class Menu < ActiveRecord::Base
  attr_accessible :description, :dishName, :price
end
