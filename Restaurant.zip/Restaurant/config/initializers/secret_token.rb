# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Restaurant::Application.config.secret_token = '168017c6c56bb5c24a3cc049cea20e3c989e9259587b49590bf9ca17ad65eb6678e05ccab6bf8c7f6827dde308421e823a19db371411e40e8fe5e57081359258'
